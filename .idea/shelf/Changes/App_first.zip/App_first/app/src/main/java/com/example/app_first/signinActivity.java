package com.example.app_first;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class signinActivity extends AppCompatActivity {
    private EditText ho, ten, tk, mk, remk, dc, mail;
    private Button dangky;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_activity);
        mAuth = FirebaseAuth.getInstance();
        ho = findViewById(R.id.ho);
        ten = findViewById(R.id.ten);
        tk = findViewById(R.id.tk);
        mk = findViewById(R.id.mk);
        remk = findViewById(R.id.remk);
        dc = findViewById(R.id.dc);
        mail = findViewById(R.id.mail);
        dangky = findViewById(R.id.dangky);
        dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {dky();
            }
        });
    }

    private void dky() {
        String email, pass;
        email = mail.getText().toString();
        pass = mk.getText().toString();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Vui lòng nhập email!!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(pass)) {
            Toast.makeText(this, "Vui lòng nhập password!!", Toast.LENGTH_SHORT).show();
            return;
        }
        mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
                    Intent c = new Intent(signinActivity.this, loginActivity.class);
                    startActivity(c);
                } else {
                    Toast.makeText(getApplicationContext(), "Đăng ký không thành công!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }}
